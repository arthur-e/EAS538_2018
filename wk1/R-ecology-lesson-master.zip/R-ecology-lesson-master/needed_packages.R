# needed packages

# save yourself some aggrevation, and have everyone check and see if they can
# install all these packages before you start the first day
library(gridExtra) # ggplot
library(hexbin) # ggplot
library(dbplyr) # R and databases
library(RSQLite) # R and databases
library(tidyverse) # lesson 3 onwards
# all of these are apart of tidyverse, but sometimes learners are unable
# to install tidyverse, and need to install them individually, so here they are
library(lubridate)
library(readr)
library(ggplot2)
library(dplyr)
library(magrittr)
library(tidyr)
